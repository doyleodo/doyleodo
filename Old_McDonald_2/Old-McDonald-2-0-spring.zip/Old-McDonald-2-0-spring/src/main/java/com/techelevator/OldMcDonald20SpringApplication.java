package com.techelevator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OldMcDonald20SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(OldMcDonald20SpringApplication.class, args);
	}

}
